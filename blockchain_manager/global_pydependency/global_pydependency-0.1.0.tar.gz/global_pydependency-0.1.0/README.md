# global_pydependency

## Overview

`global_pydependency` is a Python package designed to facilitate dependency injection and service registration in your applications. It provides a base service registry and controller to help manage and register services and routes efficiently.

## Installation

To install the package, use `poetry`:

```bash
poetry add global_pydependency