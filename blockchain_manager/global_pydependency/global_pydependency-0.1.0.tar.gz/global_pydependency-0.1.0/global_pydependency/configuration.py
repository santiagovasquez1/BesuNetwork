import os


class Configuration(dict):
    def __init__(self):
        super().__init__(os.environ)

    def __getitem__(self, key):
        return super().get(key, None)
