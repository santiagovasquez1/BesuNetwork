from abc import ABC, abstractmethod
from typing import Union

from azure.functions import Blueprint
from fastapi import APIRouter
from global_pydependency.dependency_injector import DependencyContainer


class BaseController(ABC):
    def __init__(self, container: DependencyContainer, router: Union[APIRouter, Blueprint]):
        self.container = container
        self.router = router
        self.register_routes()

    @abstractmethod
    def register_routes(self):
        pass
